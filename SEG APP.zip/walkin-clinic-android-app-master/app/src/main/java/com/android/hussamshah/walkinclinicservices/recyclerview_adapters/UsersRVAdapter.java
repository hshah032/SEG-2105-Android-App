package com.android.hussamshah.walkinclinicservices.recyclerview_adapters;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.hussamshah.walkinclinicservices.R;
import com.android.hussamshah.walkinclinicservices.db.DBHelper;
import com.android.hussamshah.walkinclinicservices.models.UserModel;

import java.util.List;

public class UsersRVAdapter extends RecyclerView.Adapter<UsersRVAdapter.ViewHolder> {

    private DBHelper db;
    private Context context;
    private List<UserModel> nonAdminUsers;

    public UsersRVAdapter(Context context, DBHelper db) {
        super();
        this.db = db;
        this.context = context;
        this.nonAdminUsers = db.getAllNonAdminUsers();
    }

    @Override
    public UsersRVAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(context).inflate(R.layout.user_item, parent, false);
        return new UsersRVAdapter.ViewHolder(item);
    }

    @Override
    public void onBindViewHolder(UsersRVAdapter.ViewHolder holder, int position) {
        UserModel user = this.nonAdminUsers.get(position);
        holder.tvUserName.setText(user.getUserName());
        holder.tvRole.setText(user.getRole().toString());
    }

    @Override
    public int getItemCount() {
        return this.nonAdminUsers.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvUserName, tvRole;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvRole = itemView.findViewById(R.id.tv_role);
            tvUserName = itemView.findViewById(R.id.tv_user_name);
            itemView.findViewById(R.id.btn_delete_user).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    UserModel user = nonAdminUsers.get(getAdapterPosition());
                    String deleteMsg = context.getString(R.string.failed_to_delete) + " " + user.getUserName();
                    if (db.deleteUser(user)) {
                        deleteMsg = context.getString(R.string.deleted) + " " + user.getUserName();
                        nonAdminUsers = db.getAllNonAdminUsers();
                        notifyDataSetChanged();
                    }
                    Toast.makeText(
                            context,
                            deleteMsg,
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });
        }
    }
}
