package com.android.hussamshah.walkinclinicservices.db;

public class Service {
    public static final String COL_ID = "_id";

    public static final String TABLE_NAME = "service";
    public static final String COL_NAME = "name";
    public static final String COL_CREATOR_ID = "creator_id";
    public static final String COL_DESCRIPTION = "description";

    public static final String[] COLUMNS = {
            COL_ID,
            COL_CREATOR_ID,
            COL_NAME,
            COL_DESCRIPTION
    };

    public static final String CREATE_SERVICE_SQL = "CREATE TABLE " +
            TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_CREATOR_ID + " INTEGER, " +
                COL_NAME + " TEXT, " +
                COL_DESCRIPTION + " TEXT " +
            ");";


}
