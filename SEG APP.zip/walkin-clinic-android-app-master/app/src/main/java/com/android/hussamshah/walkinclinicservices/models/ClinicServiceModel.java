package com.android.hussamshah.walkinclinicservices.models;

public class ClinicServiceModel extends ServiceModel {
    private double rate;
    private long serviceID;

    private long clinicID;

    public ClinicServiceModel(long id, long creatorID, long serviceID, long clinicID,  String name, String description, double rate) {
        super(id, creatorID, name, description);
        this.rate = rate;
        this.serviceID = serviceID;
        this.clinicID = clinicID;
    }

    public ClinicServiceModel(long creatorID, long serviceID, long clinicID, String name, String description, double rate) {
        this(-1, serviceID, creatorID, clinicID, name, description, rate);
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public long getServiceID() {
        return serviceID;
    }

    public void setServiceID(long serviceID) {
        this.serviceID = serviceID;
    }

    public long getClinicID() {
        return clinicID;
    }

    public void setClinicID(long clinicID) {
        this.clinicID = clinicID;
    }
}
