package com.android.hussamshah.walkinclinicservices;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import com.android.hussamshah.walkinclinicservices.db.DBHelper;
import com.android.hussamshah.walkinclinicservices.fragments.FragmentAdminHome;
import com.android.hussamshah.walkinclinicservices.fragments.FragmentAppointments;
import com.android.hussamshah.walkinclinicservices.fragments.FragmentAvailableClinics;
import com.android.hussamshah.walkinclinicservices.fragments.FragmentEmployeeHome;
import com.android.hussamshah.walkinclinicservices.fragments.FragmentLoginUser;
import com.android.hussamshah.walkinclinicservices.fragments.FragmentManageClinics;
import com.android.hussamshah.walkinclinicservices.fragments.FragmentManageUsers;
import com.android.hussamshah.walkinclinicservices.fragments.FragmentPatientHome;
import com.android.hussamshah.walkinclinicservices.fragments.FragmentRegisterUser;
import com.android.hussamshah.walkinclinicservices.models.ClinicModel;
import com.android.hussamshah.walkinclinicservices.models.ServiceModel;
import com.android.hussamshah.walkinclinicservices.models.UserModel;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity implements
        FragmentRegisterUser.IFragmentRegisterUser,
        FragmentLoginUser.IFragmentLoginUser,
        FragmentAdminHome.IFragmentAdminHome,
        FragmentManageUsers.IFragmentManageUsers,
        FragmentEmployeeHome.IFragmentEmployeeHome,
        FragmentPatientHome.IFragmentPatientHome,
        FragmentAppointments.IFragmentAppointments,
        FragmentAvailableClinics.IFragmentAvailableClinics,
        FragmentManageClinics.IFragmentManageClinics
{
    private View rootView;
    private UserModel user;
    private DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rootView = findViewById(R.id.main_frame);
        db = new DBHelper(this);

        if (savedInstanceState != null) {
            return;
        }

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.add(R.id.main_frame, FragmentRegisterUser.newInstance());
        ft.commit();
    }

    private void replaceFragment(Fragment fragment, boolean addToBackstack) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.main_frame, fragment);
        if (addToBackstack) {
            ft.addToBackStack(fragment.getClass().getName());
        }
        ft.commit();
    }

    @Override
    public void switchToRegister() {
        this.replaceFragment(FragmentRegisterUser.newInstance(), false);
    }

    @Override
    public void onLoginSuccess(UserModel user) {
        this.user = user;
        this.showUserHome(user);
        Snackbar.make(
                rootView,
                getString(R.string.welcome) + ", " + user.getFirstName(),
                Snackbar.LENGTH_LONG
        ).show();
    }

    @Override
    public void switchToLogin() {
        this.replaceFragment(FragmentLoginUser.newInstance(), false);
    }

    @Override
    public void onRegisterSuccess(UserModel user) {
        this.user = user;
        this.showUserHome(user);
        Snackbar.make(
                rootView,
                getString(R.string.welcome) + ", " + user.getFirstName(),
                Snackbar.LENGTH_LONG
        ).show();
    }

    private void showUserHome(UserModel user) {
        UserModel.Role role = user.getRole();
        switch(role) {
            case ADMIN: {
                this.replaceFragment(FragmentAdminHome.newInstance(user.getFirstName()), true);
                break;
            }
            case PATIENT: {
                this.replaceFragment(FragmentPatientHome.newInstance(user.getFirstName()), true);
                break;
            }
            case EMPLOYEE: {
                this.replaceFragment(FragmentEmployeeHome.newInstance(user.getUserID()), true);
                break;
            }
        }
    }

    @Override
    public void onManageUsers() {
        this.replaceFragment(FragmentManageUsers.newInstance(this.user.getUserID()), true);
    }

    @Override
    public void onManageClinics() {
        this.replaceFragment(FragmentManageClinics.newInstance(), true);
    }

    @Override
    public void onManageClinicServices() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.title_add_new_service));
        View view = LayoutInflater.from(this).inflate(R.layout.add_new_clinic_service, null);
        final EditText etName = view.findViewById(R.id.et_service_name);
        builder.setView(view);
        builder.setPositiveButton(R.string.save, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                if (db.createService(new ServiceModel(user.getUserID(), etName.getText().toString(), ""))) {
                    Snackbar.make(rootView, getString(R.string.successful_clinic_service_creation), Snackbar.LENGTH_SHORT).show();
                    dialog.dismiss();
                } else {
                    Snackbar.make(rootView, getString(R.string.failed_clinic_service_creation), Snackbar.LENGTH_SHORT).show();
                }
            }
        });
        builder.show();
    }

    @Override
    public void onExitManangeUsers() {
        getSupportFragmentManager().popBackStack();
    }

    @Override
    public void onExitManangeClinics() {
        getSupportFragmentManager().popBackStack();
    }

    @Override
    public void onClinicCreated(ClinicModel cm) {
        Snackbar.make(rootView, getString(R.string.clinic_creation_success), Snackbar.LENGTH_SHORT).show();
    }

    @Override
    public void switchToAppointments() {
        this.replaceFragment(FragmentAppointments.newInstance(user.getUserID()), true);
    }

    @Override
    public void switchToAvailableClinics() {
        this.replaceFragment(FragmentAvailableClinics.newInstance(user.getUserID()), true);
    }
}
