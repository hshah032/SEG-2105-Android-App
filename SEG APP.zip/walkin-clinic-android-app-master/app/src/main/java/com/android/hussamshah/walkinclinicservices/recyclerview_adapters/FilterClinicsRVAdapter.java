package com.android.hussamshah.walkinclinicservices.recyclerview_adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.hussamshah.walkinclinicservices.R;
import com.android.hussamshah.walkinclinicservices.models.ClinicModel;

import java.text.SimpleDateFormat;
import java.util.List;

public class FilterClinicsRVAdapter extends RecyclerView.Adapter<FilterClinicsRVAdapter.ViewHolder> {

    private List<ClinicModel> clinics;
    private Context context;
    private IFilterClinicsRVAdapter mListener;

    public FilterClinicsRVAdapter(Context context, List<ClinicModel> clinics, IFilterClinicsRVAdapter mListener) {
        super();
        this.context = context;
        this.clinics = clinics;
        this.mListener = mListener;
    }

    @Override
    public FilterClinicsRVAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(context).inflate(R.layout.clinic_item, parent, false);
        return new FilterClinicsRVAdapter.ViewHolder(item);
    }

    @Override
    public void onBindViewHolder(FilterClinicsRVAdapter.ViewHolder holder, int position) {
        ClinicModel clinic = this.clinics.get(position);
        holder.tvClinicName.setText(clinic.getName());
        holder.tvClinicAddress.setText(clinic.getAddress());
        SimpleDateFormat sdf = new SimpleDateFormat( "HH:mm:ss" );
        holder.tvClosingTime.setText(sdf.format(clinic.getClosingTime()));
        holder.tvResumptionTime.setText(sdf.format(clinic.getResumptionTime()));
    }

    public void resetClinics(List<ClinicModel> clinics) {
        this.clinics = clinics;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return null == this.clinics ?  0 : this.clinics.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvClinicName, tvClinicAddress, tvResumptionTime, tvClosingTime;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvClinicAddress = itemView.findViewById(R.id.tv_clinic_address);
            tvClinicName = itemView.findViewById(R.id.tv_clinic_name);
            tvResumptionTime = itemView.findViewById(R.id.tv_resumption_time);
            tvClosingTime = itemView.findViewById(R.id.tv_closing_time);

            Button btnClinicItemAction = itemView.findViewById(R.id.btn_clinic_item_action);
            btnClinicItemAction.setText(context.getString(R.string.book_appointment));
            btnClinicItemAction.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ClinicModel cm = clinics.get(getAdapterPosition());
                    mListener.onClinicClicked(cm);
                }
            });
        }
    }

    public interface IFilterClinicsRVAdapter {
        void onClinicClicked(ClinicModel cm);
    }
}
