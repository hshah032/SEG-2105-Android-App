package com.android.hussamshah.walkinclinicservices.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.android.hussamshah.walkinclinicservices.models.ClinicModel;
import com.android.hussamshah.walkinclinicservices.models.ClinicServiceModel;
import com.android.hussamshah.walkinclinicservices.models.ServiceModel;
import com.android.hussamshah.walkinclinicservices.models.UserModel;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String TAG = "DBHelper";

    private static final int DB_VERSION = 9;
    private static final String DB_NAME = "walk_in_clinic";



    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // create users table
        db.execSQL(User.CREATE_USER_SQL);
        db.execSQL(Service.CREATE_SERVICE_SQL);
        db.execSQL(Clinic.CREATE_CLINIC_SQL);
        db.execSQL(ClinicService.CREATE_CLINIC_SERVICE_SQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + User.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + Service.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + Clinic.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + ClinicService.TABLE_NAME);

        // Create tables again
        onCreate(db);
    }

    public UserModel findUser(String selection, String[] selectionArgs) {
        UserModel user = null;

        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(
                User.TABLE_NAME,
                User.COLUMNS,
                selection,
                selectionArgs,
                null,
                null,
                null,
                "1"
        );

        if(c.moveToFirst()) {
            try {
                user = new UserModel(
                        c.getLong(c.getColumnIndex(User.COL_ID)),
                        c.getString(c.getColumnIndex(User.COL_FIRST_NAME)),
                        c.getString(c.getColumnIndex(User.COL_LAST_NAME)),
                        c.getString(c.getColumnIndex(User.COL_USERNAME)),
                        c.getString(c.getColumnIndex(User.COL_PASSWORD)),
                        UserModel.Role.valueOf(c.getString(c.getColumnIndex(User.COL_ROLE)))
                );
                user.setPassword(UserModel.getPasswordHash(user.getPassword()));
            } catch (Exception ex) {
                Log.e(TAG, "Failed to find user: " + ex.getMessage());
            }
        }

        db.close();

        return user;
    }

    public UserModel findUserByID(long id) {
        return this.findUser(
                User.COL_ID + "=?",
                new String[]{String.valueOf(id)}
        );
    }

    public List<UserModel> getAllNonAdminUsers() {
        SQLiteDatabase db = this.getReadableDatabase();

        List<UserModel> users = new ArrayList<>();

        Cursor c = db.query(
                User.TABLE_NAME, User.COLUMNS,
                User.COL_ROLE + "!=?",
                new String[]{UserModel.Role.ADMIN.toString()},
                null,
                null,
                null,
                null
        );

        while(c.moveToNext()) {
            users.add(
                    new UserModel(
                            c.getLong(c.getColumnIndex(User.COL_ID)),
                            c.getString(c.getColumnIndex(User.COL_FIRST_NAME)),
                            c.getString(c.getColumnIndex(User.COL_LAST_NAME)),
                            c.getString(c.getColumnIndex(User.COL_USERNAME)),
                            c.getString(c.getColumnIndex(User.COL_PASSWORD)),
                            UserModel.Role.valueOf(c.getString(c.getColumnIndex(User.COL_ROLE)))
                    )
            );
        }

        db.close();

         return users;
    }

    public UserModel findUserByUsernameAndPassword(String userName, String password) {
        UserModel user = null;
        try {
            user = this.findUser(
                    User.COL_USERNAME + "=? AND " + User.COL_PASSWORD + "=?",
                    new String[]{userName, UserModel.getPasswordHash(password)}
            );
        } catch (Exception ex) {
            Log.e(TAG, "failed to find user: " + ex.getMessage());
        }

        return user;
    }

    public boolean createUser(UserModel user) {
        boolean success = true;
        SQLiteDatabase db = this.getWritableDatabase();

        try {
            ContentValues cv = new ContentValues();
            cv.put(User.COL_FIRST_NAME, user.getFirstName());
            cv.put(User.COL_LAST_NAME, user.getLastName());
            cv.put(User.COL_PASSWORD, UserModel.getPasswordHash(user.getPassword()));
            cv.put(User.COL_ROLE, user.getRole().toString());
            cv.put(User.COL_USERNAME, user.getUserName());

            long colID = db.insert(User.TABLE_NAME, null, cv);
            user.setUserID(colID);

        } catch (Exception ex) {
            success = false;
        }

        db.close();

        return success;
    }

    public boolean deleteUser(UserModel user) {
        SQLiteDatabase db = this.getWritableDatabase();

        int count = db.delete(User.TABLE_NAME, User.COL_ID + "=?", new String[]{String.valueOf(user.getUserID())});

        db.close();

        return count > 0;
    }

    public boolean createService(ServiceModel csm) {
        ContentValues cv = new ContentValues();
        cv.put(Service.COL_CREATOR_ID, csm.getCreatorID());
        cv.put(Service.COL_NAME, csm.getName());
        cv.put(Service.COL_DESCRIPTION, csm.getDescription());

        SQLiteDatabase db = this.getWritableDatabase();
        long id = db.insert(Service.TABLE_NAME, null, cv);

        csm.setId(id);

        db.close();

        return id > 0;
    }

    public List<ServiceModel> getAllServices() {
        List<ServiceModel> services = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                Service.TABLE_NAME,
                Service.COLUMNS,
                null,
                null,
                null,
                null,
                null
        );

        while(cursor.moveToNext()) {
            services.add(new ServiceModel(
                    cursor.getLong(cursor.getColumnIndex(Service.COL_ID)),
                    cursor.getLong(cursor.getColumnIndex(Service.COL_CREATOR_ID)),
                    cursor.getString(cursor.getColumnIndex(Service.COL_NAME)),
                    cursor.getString(cursor.getColumnIndex(Service.COL_DESCRIPTION))
            ));
        }

        db.close();

        return services;
    }

    public boolean createClinic(ClinicModel cm) {
        ContentValues cv = new ContentValues();
        cv.put(Clinic.COL_ADDRESS, cm.getAddress());
        cv.put(Clinic.COL_CREATOR_ID, cm.getCreatorID());
        cv.put(Clinic.COL_ADDRESS, cm.getAddress());
        cv.put(Clinic.COL_CLOSE_TIME, cm.getClosingTime().getTime());
        cv.put(Clinic.COL_NAME, cm.getName());
        cv.put(Clinic.COL_RESUMPTION_TIME, cm.getResumptionTime().getTime());

        SQLiteDatabase db = this.getWritableDatabase();
        long id = db.insert(Clinic.TABLE_NAME, null, cv);

        cm.setId(id);

        db.close();

        return id > 0;
    }

    public boolean deleteClinic(ClinicModel cm) {
        SQLiteDatabase db = this.getWritableDatabase();

        int count = db.delete(Clinic.TABLE_NAME, User.COL_ID + "=?", new String[]{String.valueOf(cm.getId())});

        db.close();

        return count > 0;
    }

    public List<ClinicModel> getAllClinics() {
        SQLiteDatabase db = getReadableDatabase();

        List<ClinicModel> clinics = new ArrayList<>();

        Cursor cursor = db.query(
                Clinic.TABLE_NAME,
                Clinic.COLUMNS,
                null,
                null,
                null,
                null,
                null
        );

        while(cursor.moveToNext()) {
            Date resumptionTime = Calendar.getInstance().getTime();
            resumptionTime.setTime(cursor.getLong(cursor.getColumnIndex(Clinic.COL_RESUMPTION_TIME)));

            Date closingTime = Calendar.getInstance().getTime();
            closingTime.setTime(cursor.getLong(cursor.getColumnIndex(Clinic.COL_CLOSE_TIME)));

            ClinicModel c = new ClinicModel(
                    cursor.getLong(cursor.getColumnIndex(Clinic.COL_ID)),
                    cursor.getLong(cursor.getColumnIndex(Clinic.COL_CREATOR_ID)),
                    cursor.getString(cursor.getColumnIndex(Clinic.COL_NAME)),
                    cursor.getString(cursor.getColumnIndex(Clinic.COL_ADDRESS)),
                    resumptionTime,
                    closingTime
            );
            Log.d(TAG, "added Clinic: " + c.toString());
            clinics.add(c);
        }

        db.close();

        return clinics;
    }

    public boolean createClinicService(ClinicServiceModel csm) {
        ContentValues cv = new ContentValues();
        cv.put(ClinicService.COL_CREATOR_ID, csm.getCreatorID());
        cv.put(ClinicService.COL_SERVICE_ID, csm.getServiceID());
        cv.put(ClinicService.COL_NAME, csm.getName());
        cv.put(ClinicService.COL_DESCRIPTION, csm.getDescription());
        cv.put(ClinicService.COL_NAME, csm.getName());
        cv.put(ClinicService.COL_DESCRIPTION, csm.getDescription());
        cv.put(ClinicService.COL_CLINIC_ID, csm.getClinicID());

        SQLiteDatabase db = this.getWritableDatabase();
        long id = db.insert(ClinicService.TABLE_NAME, null, cv);

        csm.setId(id);

        db.close();

        return id > 0;
    }

    public List<ClinicServiceModel> getAllClinicServices(long clinicID) {
        List<ClinicServiceModel> services = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                ClinicService.TABLE_NAME,
                ClinicService.COLUMNS,
                ClinicService.COL_CLINIC_ID + "=?",
                new String[]{String.valueOf(clinicID)},
                null,
                null,
                null
        );

        while(cursor.moveToNext()) {
            services.add(new ClinicServiceModel(
                    cursor.getLong(cursor.getColumnIndex(ClinicService.COL_ID)),
                    cursor.getLong(cursor.getColumnIndex(ClinicService.COL_CREATOR_ID)),
                    cursor.getLong(cursor.getColumnIndex(ClinicService.COL_SERVICE_ID)),
                    cursor.getLong(cursor.getColumnIndex(ClinicService.COL_CLINIC_ID)),
                    cursor.getString(cursor.getColumnIndex(ClinicService.COL_NAME)),
                    cursor.getString(cursor.getColumnIndex(ClinicService.COL_DESCRIPTION)),
                    cursor.getDouble(cursor.getColumnIndex(ClinicService.COL_RATE))
            ));
        }

        db.close();

        return services;
    }


}
