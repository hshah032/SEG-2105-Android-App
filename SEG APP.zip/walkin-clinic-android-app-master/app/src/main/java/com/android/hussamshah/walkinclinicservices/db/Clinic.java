package com.android.hussamshah.walkinclinicservices.db;

public class Clinic {
    public static final String COL_ID = "_id";

    public static final String TABLE_NAME = "clinic";
    public static final String COL_NAME = "name";
    public static final String COL_CREATOR_ID = "creator_id";
    public static final String COL_ADDRESS = "address";
    public static final String COL_RESUMPTION_TIME = "resumption_time";
    public static final String COL_CLOSE_TIME = "close_time";

    public static final String[] COLUMNS = {
            COL_ID,
            COL_CREATOR_ID,
            COL_NAME,
            COL_ADDRESS,
            COL_CLOSE_TIME,
            COL_RESUMPTION_TIME
    };

    public static final String CREATE_CLINIC_SQL = "CREATE TABLE " +
            TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_CREATOR_ID + " INTEGER, " +
                COL_NAME + " TEXT, " +
                COL_RESUMPTION_TIME + " INTEGER, " +
                COL_CLOSE_TIME + " INTEGER, " +
                COL_ADDRESS + " TEXT " +
            ");";


}
