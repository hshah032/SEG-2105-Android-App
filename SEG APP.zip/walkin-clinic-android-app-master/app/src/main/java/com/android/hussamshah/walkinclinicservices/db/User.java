package com.android.hussamshah.walkinclinicservices.db;

public class User {
    public static final String COL_ID = "_id";

    public static final String TABLE_NAME = "users";
    public static final String COL_FIRST_NAME = "firstname";
    public static final String COL_LAST_NAME = "lastname";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";
    public static final String COL_ROLE = "role";

    public static final String[] COLUMNS = {
            COL_ID,
            COL_USERNAME,
            COL_FIRST_NAME,
            COL_LAST_NAME,
            COL_PASSWORD,
            COL_ROLE
    };

    public static final String CREATE_USER_SQL = "CREATE TABLE " +
            TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_FIRST_NAME + " TEXT, " +
                COL_LAST_NAME + " TEXT, " +
                COL_USERNAME + " TEXT, " +
                COL_PASSWORD + " TEXT, " +
                COL_ROLE +  " TEXT, " +
                " UNIQUE (" +
                    COL_USERNAME  +
                ")"
            +");";


}
