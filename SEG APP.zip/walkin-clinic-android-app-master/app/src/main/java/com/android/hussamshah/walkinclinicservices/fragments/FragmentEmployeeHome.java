package com.android.hussamshah.walkinclinicservices.fragments;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.hussamshah.walkinclinicservices.R;
import com.android.hussamshah.walkinclinicservices.db.DBHelper;
import com.android.hussamshah.walkinclinicservices.models.ClinicModel;
import com.android.hussamshah.walkinclinicservices.models.ClinicServiceModel;
import com.android.hussamshah.walkinclinicservices.models.ServiceModel;
import com.google.android.material.snackbar.Snackbar;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link IFragmentEmployeeHome} interface
 * to handle interaction events.
 * Use the {@link FragmentEmployeeHome#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentEmployeeHome extends Fragment implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    private static  final String ARG_USER_ID = "arg1";


    private IFragmentEmployeeHome mListener;
    private DBHelper db;
    private EditText etName, etAddress, etResumptionTime, etClosingTime;
    private Spinner spinner;
    private List<ClinicServiceModel> clinicServices;
    private List<ServiceModel> services;
    private long userID;
    private Calendar calendarClosingTime = Calendar.getInstance();
    private Calendar calendarResumptionTime = Calendar.getInstance();

    public FragmentEmployeeHome() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment FragmentEmployeeHome.
     */
    public static FragmentEmployeeHome newInstance(long userID) {
        FragmentEmployeeHome fragment = new FragmentEmployeeHome();
        Bundle args = new Bundle();
        args.putLong(ARG_USER_ID, userID);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (null != args) {
            this.userID = args.getLong(ARG_USER_ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_employee_home, container, false);
        this.services = db.getAllServices();
        this.services.add(0, new ServiceModel(-1, -1, "Select Service",""));
        this.clinicServices = new ArrayList<>();

        spinner = view.findViewById(R.id.spinner_services);
        ArrayAdapter<ServiceModel> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item,services);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setOnItemSelectedListener(this);
        spinner.setAdapter(adapter);

        etAddress = view.findViewById(R.id.et_address);
        etName = view.findViewById(R.id.et_name);
        etResumptionTime = view.findViewById(R.id.et_resumption_time);
        etResumptionTime.setOnClickListener(this);
        etClosingTime = view.findViewById(R.id.et_closing_time);
        etClosingTime.setOnClickListener(this);

        view.findViewById(R.id.btn_save).setOnClickListener(this);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.db = new DBHelper(context);
        if (context instanceof IFragmentEmployeeHome) {
            mListener = (IFragmentEmployeeHome) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement IFragmentEmployeeHome");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
        this.db = null;
    }

    public static void selectTime(Context context, final Calendar calendar, final EditText et) {
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minutes = calendar.get(Calendar.MINUTE);
        // time picker dialog
        new TimePickerDialog(context,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker tp, int sHour, int sMinute) {
                        calendar.set(Calendar.HOUR_OF_DAY, sHour);
                        calendar.set(Calendar.MINUTE, sMinute);
                        SimpleDateFormat sdf = new SimpleDateFormat( "HH:mm:ss" );
                        String time = sdf.format( calendar.getTime() );

                        et.setText(time);
                    }
                }, hour, minutes, true).show();
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.et_closing_time: {
                this.selectTime(getContext(), this.calendarClosingTime, this.etClosingTime);
                break;
            }
            case R.id.et_resumption_time: {
                this.selectTime(getContext(), calendarResumptionTime, this.etResumptionTime);
                break;
            }
            case R.id.btn_save: {
                boolean hasError = false;
                String name = this.etName.getText().toString();
                String address = this.etAddress.getText().toString();
                String resumptionTime = this.etResumptionTime.getText().toString();
                String closingTime = this.etClosingTime.getText().toString();

                if (name.isEmpty()) {
                    hasError = true;
                    this.etName.setError(getString(R.string.required));
                } else {
                    this.etName.setError(null);
                }

                if (address.isEmpty()) {
                    hasError = true;
                    this.etAddress.setError(getString(R.string.required));
                } else {
                    this.etAddress.setError(null);
                }

                if (resumptionTime.isEmpty()) {
                    hasError = true;
                    this.etResumptionTime.setError(getString(R.string.required));
                } else {
                    this.etResumptionTime.setError(null);
                }

                if (closingTime.isEmpty()) {
                    hasError = true;
                    this.etClosingTime.setError(getString(R.string.required));
                } else {
                    this.etClosingTime.setError(null);
                }

                if (this.calendarClosingTime.before(this.calendarResumptionTime)) {
                    hasError = true;
                    Toast.makeText(getContext(), getString(R.string.invalid_resumption_and_closing_time), Toast.LENGTH_SHORT).show();
                }

                if (this.clinicServices.size() < 1) {
                    hasError = true;
                    Toast.makeText(getContext(), getString(R.string.at_least_one_clinic_service_required), Toast.LENGTH_SHORT).show();
                }

                if (hasError) {
                    return;
                }

                ClinicModel cm = new ClinicModel(userID, name, address, this.calendarResumptionTime.getTime(), this.calendarClosingTime.getTime());
                if (!db.createClinic(cm)) {
                    Toast.makeText(getContext(), getString(R.string.failed_clinic_creation), Toast.LENGTH_SHORT).show();
                    return;
                }

                // insert the services
                for (ClinicServiceModel csm: this.clinicServices) {
                    csm.setClinicID(cm.getId());
                    if (!db.createClinicService(csm)) {
                        Toast.makeText(getContext(), getString(R.string.failed_clinic_service_creation), Toast.LENGTH_SHORT).show();
                    }
                }

                this.mListener.onClinicCreated(cm);

                break;
            }
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        if (position == 0) {
            return;
        }
        final ServiceModel sm = this.services.get(position);
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(R.string.title_register_clinic_service);
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.register_clinic_service, null);
        ((TextView)dialogView.findViewById(R.id.tv_title)).setText(sm.getName());
        final EditText etRate = dialogView.findViewById(R.id.et_rate);
        builder.setView(dialogView);

        builder.setPositiveButton(R.string.save, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                // remember to always set the clinic id after inserting a clinic.
                ClinicServiceModel csm = new ClinicServiceModel(userID, sm.getId(), -1, sm.getName(), sm.getDescription(), Double.valueOf(etRate.getText().toString()));
                clinicServices.add(csm);
            }
        });

        builder.show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface IFragmentEmployeeHome {
        void onClinicCreated(ClinicModel cm);
    }
}
