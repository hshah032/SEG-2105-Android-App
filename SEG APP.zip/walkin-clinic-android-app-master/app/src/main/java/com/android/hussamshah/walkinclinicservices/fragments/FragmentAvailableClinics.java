package com.android.hussamshah.walkinclinicservices.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Spinner;

import com.android.hussamshah.walkinclinicservices.R;
import com.android.hussamshah.walkinclinicservices.db.DBHelper;
import com.android.hussamshah.walkinclinicservices.models.ClinicModel;
import com.android.hussamshah.walkinclinicservices.recyclerview_adapters.FilterClinicsRVAdapter;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link IFragmentAvailableClinics} interface
 * to handle interaction events.
 * Use the {@link FragmentAvailableClinics#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentAvailableClinics extends Fragment implements FilterClinicsRVAdapter.IFilterClinicsRVAdapter {
    private static final String ARG_USER_ID = "param1";
    private static final String TAG = "FragmentAvailableClinic";

    private long userID;
    private DBHelper db;
    private RecyclerView recyclerView;
    private EditText etClinicAddressFilter, etWorkingHoursFilter;
    private Spinner spinnerClinicServiceFilter;
    private IFragmentAvailableClinics mListener;
    private String addressFilter;
    private List<ClinicModel> allClinics;
    private FilterClinicsRVAdapter rvAdapter;
    private Calendar workingTime;

    public FragmentAvailableClinics() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment FragmentAvailableClinics.
     */
    public static FragmentAvailableClinics newInstance(long userID) {
        FragmentAvailableClinics fragment = new FragmentAvailableClinics();
        Bundle args = new Bundle();
        args.putLong(ARG_USER_ID, userID);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            this.userID = getArguments().getLong(ARG_USER_ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_available_clinics, container, false);

        this.addressFilter = "";

        this.allClinics =  this.db.getAllClinics();
        rvAdapter = new FilterClinicsRVAdapter(getContext(), allClinics, this);

        recyclerView = view.findViewById(R.id.rv_clinics);
        recyclerView.setAdapter(rvAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setHasFixedSize(true);

        this.etClinicAddressFilter = view.findViewById(R.id.et_clinic_address);
        this.etClinicAddressFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void afterTextChanged(Editable editable) {
                addressFilter = editable.toString();
                filterClinics();
            }
        });

        this.workingTime = Calendar.getInstance();
        this.etWorkingHoursFilter = view.findViewById(R.id.et_working_hours);
        this.etWorkingHoursFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override
            public void afterTextChanged(Editable editable) {
                if(editable.toString().isEmpty()) { return; }
                filterClinics();
            }
        });
        this.etWorkingHoursFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentEmployeeHome.selectTime(getContext(), workingTime, etWorkingHoursFilter);
            }
        });

        return view;
    }

    private void filterClinics() {
        List<ClinicModel> filteredClinics = new ArrayList<>();
        filteredClinics.addAll(allClinics);
        if (!addressFilter.isEmpty()) {
            filteredClinics.clear();
            for (ClinicModel c: allClinics) {
                String address = c.getAddress().toLowerCase();
                Log.d(TAG, "addressFilter: " + addressFilter + ", clinicAddress: " + address);
                if(address.contains(addressFilter.toLowerCase())) {
                    filteredClinics.add(c);
                }
            }
        }

        if (!this.etWorkingHoursFilter.getText().toString().isEmpty()) {
            List<ClinicModel> prev = new ArrayList<>();
            prev.addAll(filteredClinics);
            filteredClinics.clear();
            for (ClinicModel c : prev) {
                if(c.getClosingTime().after(workingTime.getTime()) && c.getResumptionTime().before(workingTime.getTime())) {
                    filteredClinics.add(c);
                }
            }
        }

        this.rvAdapter.resetClinics(filteredClinics);
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.db = new DBHelper(context);
        if (context instanceof IFragmentAvailableClinics) {
            this.mListener = (IFragmentAvailableClinics) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement IFragmentAvailableClinics");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
       this. mListener = null;
        this.db = null;
    }

    @Override
    public void onClinicClicked(ClinicModel cm) {

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface IFragmentAvailableClinics {
    }
}
