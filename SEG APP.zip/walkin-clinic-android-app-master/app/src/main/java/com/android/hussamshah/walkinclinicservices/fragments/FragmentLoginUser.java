package com.android.hussamshah.walkinclinicservices.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.android.hussamshah.walkinclinicservices.R;
import com.android.hussamshah.walkinclinicservices.db.DBHelper;
import com.android.hussamshah.walkinclinicservices.models.UserModel;
import com.google.android.material.snackbar.Snackbar;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link IFragmentLoginUser} interface
 * to handle interaction events.
 * Use the {@link FragmentLoginUser#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentLoginUser extends Fragment implements View.OnClickListener  {
    private static final String TAG = "FragmentLoginUser";

    private DBHelper db;
    private IFragmentLoginUser mListener;
    private EditText etUsername, etPassword;

    public FragmentLoginUser() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment FragmentLoginUser.
     */
    public static FragmentLoginUser newInstance() {
        FragmentLoginUser fragment = new FragmentLoginUser();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login_user, container, false);

        view.findViewById(R.id.btn_register).setOnClickListener(this);
        view.findViewById(R.id.btn_login).setOnClickListener(this);

        this.etPassword = view.findViewById(R.id.et_password);
        this.etUsername = view.findViewById(R.id.et_user_name);

        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        db = new DBHelper(context);
        if (context instanceof IFragmentLoginUser) {
            mListener = (IFragmentLoginUser) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement IFragmentLoginUser");
        }
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btn_register: {
                this.mListener.switchToRegister();
                break;
            }
            case R.id.btn_login: {
                this.login();
                break;
            }
        }
    }

    private void login() {
        boolean hasError = false;

        String userName = this.etUsername.getText().toString();
        String password = this.etPassword.getText().toString();

        if (userName.isEmpty()) {
            hasError = true;
            this.etUsername.setError(getString(R.string.required));
        } else {
            this.etUsername.setError(null);
        }

        if (password.isEmpty()) {
            hasError = true;
            this.etPassword.setError(getString(R.string.required));
        } else {
            this.etPassword.setError(null);
        }

        if (hasError) {
            return;
        }

        Log.d(TAG, String.format("userName: %s, password: %s", userName, password));

        UserModel user = db.findUserByUsernameAndPassword(userName, password);

        if (null == user) {
            Snackbar.make(getView(), getString(R.string.failed_login), Snackbar.LENGTH_LONG).show();
        } else {
            Log.d(TAG, "user logged in: " + user.toString());
            mListener.onLoginSuccess(user);
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
        db = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface IFragmentLoginUser {
        void switchToRegister();
        void onLoginSuccess(UserModel user);
    }
}
