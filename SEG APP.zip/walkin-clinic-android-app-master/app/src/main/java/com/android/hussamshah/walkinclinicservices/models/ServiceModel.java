package com.android.hussamshah.walkinclinicservices.models;

public class ServiceModel {
    private long id, creatorID;
    private String name, description;

    public ServiceModel(long id, long creatorID, String name, String description) {
        super();
        this.id = id;
        this.creatorID = creatorID;
        this.name = name;
        this.description = description;
    }

    public ServiceModel(long creatorID, String name, String description) {
        this(-1, creatorID, name, description);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getCreatorID() {
        return creatorID;
    }

    public void setCreatorID(long creatorID) {
        this.creatorID = creatorID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
