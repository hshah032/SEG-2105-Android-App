package com.android.hussamshah.walkinclinicservices.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.android.hussamshah.walkinclinicservices.R;
import com.android.hussamshah.walkinclinicservices.db.DBHelper;
import com.android.hussamshah.walkinclinicservices.models.UserModel;
import com.google.android.material.snackbar.Snackbar;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link IFragmentRegisterUser} interface
 * to handle interaction events.
 * Use the {@link FragmentRegisterUser#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentRegisterUser extends Fragment implements View.OnClickListener {
    private static final String TAG = "FragmentRegisterUser";

    private IFragmentRegisterUser mListener;
    private EditText etFirstName, etLastName, etPassword, etPasswordConfirm, etUserName;
    private UserModel.Role role;

    private DBHelper db;

    public FragmentRegisterUser() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment FragmentRegisterUser.
     */
    public static FragmentRegisterUser newInstance() {
        FragmentRegisterUser fragment = new FragmentRegisterUser();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_register_user, container, false);

        view.findViewById(R.id.btn_register).setOnClickListener(this);
        view.findViewById(R.id.btn_login).setOnClickListener(this);

        this.etFirstName = view.findViewById(R.id.et_first_name);
        this.etLastName = view.findViewById(R.id.et_last_name);
        this.etPassword = view.findViewById(R.id.et_password);
        this.etPasswordConfirm = view.findViewById(R.id.et_confirm_password);
        this.etUserName = view.findViewById(R.id.et_user_name);

        ((RadioGroup)view.findViewById(R.id.rg_user_type)).setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                switch (id) {
                    case R.id.rb_admin: {
                        role = UserModel.Role.ADMIN;
                        break;
                    }
                    case R.id.rb_employee: {
                        role = UserModel.Role.EMPLOYEE;
                        break;
                    }
                    case R.id.rb_patient: {
                        role = UserModel.Role.PATIENT;
                        break;
                    }
                }
            }
        });

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        db = new DBHelper(context);
        if (context instanceof IFragmentRegisterUser) {
            mListener = (IFragmentRegisterUser) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement IFragmentRegisterUser");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
        db = null;
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btn_login: {
                this.mListener.switchToLogin();
                break;
            }
            case R.id.btn_register: {
                this.register();
                break;
            }
        }
    }

    private void register() {
        boolean hasError = false;

        String firstName = this.etFirstName.getText().toString();
        String lastName = this.etLastName.getText().toString();
        String userName = this.etUserName.getText().toString();
        String password = this.etPassword.getText().toString();
        String passwordConfirm = this.etPasswordConfirm.getText().toString();

        if (firstName.isEmpty()) {
            this.etFirstName.setError(getString(R.string.required));
            hasError = true;
        } else {
            this.etFirstName.setError(null);
        }

        if (lastName.isEmpty()) {
            this.etLastName.setError(getString(R.string.required));
            hasError = true;
        } else {
            this.etLastName.setError(null);
        }

        if (userName.isEmpty()) {
            this.etUserName.setError(getString(R.string.required));
            hasError = true;
        } else {
            this.etUserName.setError(null);
        }

        if (password.isEmpty()) {
            this.etPassword.setError(getString(R.string.required));
            hasError = true;
        } else {
            this.etPassword.setError(null);
        }


        if (!passwordConfirm.equals(password)) {
            this.etPasswordConfirm.setError(getString(R.string.passwords_must_match));
            hasError = true;
        } else {
            this.etPasswordConfirm.setError(null);
        }

        if (null == role) {
            Snackbar.make(getView(), getString(R.string.required_user_role), Snackbar.LENGTH_LONG).show();
            hasError = true;
        }

        if (hasError) {
            return;
        }

        UserModel user = new UserModel(firstName, lastName, userName, password, role);
        if (db.createUser(user)) {
            mListener.onRegisterSuccess(user);
            Log.d(TAG, "user registered: " + user.toString());
        } else {
            Snackbar.make(getView(), getString(R.string.failed_registration), Snackbar.LENGTH_LONG).show();
        }
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface IFragmentRegisterUser {
        void switchToLogin();
        void onRegisterSuccess(UserModel user);
    }
}
