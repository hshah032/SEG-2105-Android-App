package com.android.hussamshah.walkinclinicservices.recyclerview_adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.hussamshah.walkinclinicservices.R;
import com.android.hussamshah.walkinclinicservices.db.DBHelper;
import com.android.hussamshah.walkinclinicservices.models.ClinicModel;

import java.text.SimpleDateFormat;
import java.util.List;

public class ClinicsRVAdapter extends RecyclerView.Adapter<ClinicsRVAdapter.ViewHolder> {

    private DBHelper db;
    private Context context;
    private List<ClinicModel> clinics;

    public ClinicsRVAdapter(Context context, DBHelper db) {
        super();
        this.db = db;
        this.context = context;
        this.clinics = db.getAllClinics();
    }

    @Override
    public ClinicsRVAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(context).inflate(R.layout.clinic_item, parent, false);
        return new ClinicsRVAdapter.ViewHolder(item);
    }

    @Override
    public void onBindViewHolder(ClinicsRVAdapter.ViewHolder holder, int position) {
        ClinicModel clinic = this.clinics.get(position);
        holder.tvClinicName.setText(clinic.getName());
        holder.tvClinicAddress.setText(clinic.getAddress());
        SimpleDateFormat sdf = new SimpleDateFormat( "HH:mm:ss" );
        holder.tvClosingTime.setText(sdf.format(clinic.getClosingTime()));
        holder.tvResumptionTime.setText(sdf.format(clinic.getResumptionTime()));
    }

    @Override
    public int getItemCount() {
        return this.clinics.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvClinicName, tvClinicAddress, tvResumptionTime, tvClosingTime;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvClinicName = itemView.findViewById(R.id.tv_clinic_name);
            tvClinicAddress = itemView.findViewById(R.id.tv_clinic_address);
            tvResumptionTime = itemView.findViewById(R.id.tv_resumption_time);
            tvClosingTime = itemView.findViewById(R.id.tv_closing_time);

            Button btnClinicItemAction = itemView.findViewById(R.id.btn_clinic_item_action);
            btnClinicItemAction.setText(context.getString(R.string.delete_clinic));
            btnClinicItemAction.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ClinicModel cm = clinics.get(getAdapterPosition());
                    String deleteMsg = context.getString(R.string.failed_to_delete) + " " + cm.getName();
                    if (db.deleteClinic(cm)) {
                        deleteMsg = context.getString(R.string.deleted) + " " + cm.getName();
                        clinics = db.getAllClinics();
                        notifyDataSetChanged();
                    }
                    Toast.makeText(
                            context,
                            deleteMsg,
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });
        }
    }
}
