package com.android.hussamshah.walkinclinicservices.models;

import java.util.Date;

public class ClinicModel {
    protected long id, creatorID;
    protected Date resumptionTime, closingTime;
    protected String name,  address;

    public ClinicModel(long id, long creatorID, String name, String address, Date resumptionTime, Date closingTime) {
        super();
        this.creatorID = creatorID;
        this.id = id;
        this.name = name;
        this.address = address;
        this.resumptionTime = resumptionTime;
        this.closingTime = closingTime;
    }

    public ClinicModel(long creatorID, String name, String address, Date resumptionTime, Date closingTime) {
        this(-1, creatorID, name, address, resumptionTime, closingTime);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getCreatorID() {
        return creatorID;
    }

    public void setCreatorID(long creatorID) {
        this.creatorID = creatorID;
    }

    public Date getResumptionTime() {
        return resumptionTime;
    }

    public void setResumptionTime(Date resumptionTime) {
        this.resumptionTime = resumptionTime;
    }

    public Date getClosingTime() {
        return closingTime;
    }

    public void setClosingTime(Date closingTime) {
        this.closingTime = closingTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return String.format("name: %s, address: %s, id: %d, creatorID: %d, resumptionTime: %s, closingTime: %s", name, address, id, creatorID, resumptionTime.toString(), closingTime.toString());
    }
}
