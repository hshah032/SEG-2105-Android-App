package com.android.hussamshah.walkinclinicservices.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.hussamshah.walkinclinicservices.R;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link IFragmentAdminHome} interface
 * to handle interaction events.
 * Use the {@link FragmentAdminHome#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentAdminHome extends Fragment implements View.OnClickListener {
    private static final String ARG_FIRST_NAME = "param_1";

    private IFragmentAdminHome mListener;
    private String firstName;

    public FragmentAdminHome() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment FragmentAdminHome.
     */
    public static FragmentAdminHome newInstance(String firstName) {
        FragmentAdminHome fragment = new FragmentAdminHome();
        Bundle args = new Bundle();
        args.putString(ARG_FIRST_NAME, firstName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (null != args) {
            this.firstName = args.getString(ARG_FIRST_NAME);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_home, container, false);
        ((TextView)view.findViewById(R.id.tv_welcome)).setText(getString(R.string.welcome) + ", " + this.firstName);

        view.findViewById(R.id.btn_manage_clinic_services).setOnClickListener(this);
        view.findViewById(R.id.btn_manage_users).setOnClickListener(this);
        view.findViewById(R.id.btn_manage_clinics).setOnClickListener(this);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof IFragmentAdminHome) {
            mListener = (IFragmentAdminHome) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement IFragmentAdminHome");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btn_manage_clinic_services: {
                this.mListener.onManageClinicServices();
                break;
            }
            case R.id.btn_manage_clinics: {
                this.mListener.onManageClinics();
                break;
            }
            case R.id.btn_manage_users: {
                this.mListener.onManageUsers();
                break;
            }
        }
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface IFragmentAdminHome {
        void onManageUsers();
        void onManageClinics();
        void onManageClinicServices();
    }
}
