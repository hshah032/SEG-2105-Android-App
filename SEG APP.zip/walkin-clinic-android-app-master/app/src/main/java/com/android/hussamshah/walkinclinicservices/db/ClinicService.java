package com.android.hussamshah.walkinclinicservices.db;

public class ClinicService {
    public static final String COL_ID = "_id";

    public static final String TABLE_NAME = "clinic_service";
    public static final String COL_SERVICE_ID= "service_id";
    public static final String COL_CREATOR_ID= "creator_id";
    public static final String COL_RATE = "rate";
    public static final String COL_NAME = "name";
    public static final String COL_DESCRIPTION = "description";
    public static final String COL_CLINIC_ID = "clinic_id";

    public static final String[] COLUMNS = {
            COL_ID,
            COL_RATE,
            COL_SERVICE_ID,
            COL_CLINIC_ID,
            COL_NAME,
            COL_DESCRIPTION,
            COL_CREATOR_ID
    };

    public static final String CREATE_CLINIC_SERVICE_SQL = "CREATE TABLE " +
            TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_SERVICE_ID + " INTEGER, " +
                COL_CREATOR_ID + " INTEGER, " +
                COL_CLINIC_ID + " INTEGER, " +
                COL_NAME + " TEXT, " +
                COL_DESCRIPTION + " TEXT, " +
                COL_RATE + " REAL," +
                " UNIQUE (" +
                    COL_SERVICE_ID  + ", " + COL_ID +
                ")" +
            ");";
}
