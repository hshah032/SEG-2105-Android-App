package com.android.hussamshah.walkinclinicservices.models;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class UserModel {

    public enum Role {ADMIN, PATIENT, EMPLOYEE}

    private String userName, firstName, lastName, password;
    private Role role;
    private long userID;

    public UserModel(long id, String firstName, String lastName, String userName, String password, Role role) {
        super();
        this.userID = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
        this.role = role;
    }

    public UserModel(String firstName, String lastName, String userName, String password, Role role) {
        this(-1, firstName, lastName, userName, password, role);
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public long getUserID() {
        return userID;
    }

    public void setUserID(long userID) {
        this.userID = userID;
    }

    public Role getRole() { return role; }

    public void setRole(Role role) { this.role = role; }

    public static String getPasswordHash(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        // digest() method called
        // to calculate message digest of an input
        // and return array of byte
        byte[] hashBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));// Convert byte array into signum representation
        BigInteger number = new BigInteger(1, hashBytes);

        // Convert message digest into hex value
        StringBuilder hexString = new StringBuilder(number.toString(16));

        // Pad with leading zeros
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }

        return hexString.toString();
    }

    @Override
    public String toString() {
        return String.format(
                "userID: %d, firstName: %s, lastName: %s, userName: %s, password: %s, role: %s",
                this.userID, this.firstName, this.lastName, this.userName, this.password, this.role
        );
    }
}
